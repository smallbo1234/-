from library import index
print('学号:18180100109')
print('姓名:罗东旭')
# 主页
index()
