# 西电网信院 2020 春数据库大作业

## 环境依赖

Python 3.X

PyMySQL

## 部署步骤

1. 安装 [Python 3.X](https://www.python.org/downloads/release/python-383/)

- https://www.python.org/downloads/release/python-383/

2. 安装 PyMySQL

```shell
pip install pymysql
```

### 运行

```shell
python app.py
```
